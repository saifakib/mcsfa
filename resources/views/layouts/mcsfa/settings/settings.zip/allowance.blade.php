@extends('layouts.mcsfa.app')
@section('title')
Allowance
@endsection
@section('content')

<div id="contentWrapper" style="font-family: Montserrat">
            <!-- Content Header (Page header) -->
        <div class="content-wrapper">
        <section class="content-header">
        <h1>List of Allowance</h1>
        <a class="btn btn-primary" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" style="border-radius: 10px;float: right;margin-top:-30px;font-family: Montserrat;color: #fff"><i class="fa fa-plus" aria-hidden="true"></i> Add Allowance</a>
    </section>
    <section class="content animated fadeInRight">
        <div class="box-group" id="accordion">
            <div class="panel" style="border: none">
                <div id="collapseTwo" class="panel-collapse collapse">
                    <div class="box-body" style="border: 2px solid #3c8dbc">
                        <form method="post" action="{{ URL::to('/')}}/saveupdateloan">
                            <input type="hidden" name="_token" value="">
                            <input type="hidden" name="status" value="save">
                            <div class="row">
                                <div class="col-md-12">
                                    <label>Allowance Code <span style="color: red">*</span></label>
                                    <div class="form-group">
                                        <input type="text" name="allowance_code" class="form-control inputnumber" placeholder="Enter Allowance Code" required="">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <label> Title <span style="color: red">*</span></label>
                                    <div class="form-group">
                                        <input type="text" name="title" class="form-control inputtext" placeholder="Enter Title" required="">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label> Account No <span style="color: red">*</span></label>
                                    <div class="form-group">
                                        <input type="number" name="account_number" class="form-control inputtext" placeholder="Enter Account Number" required="">
                                    </div>
                                </div>
                            </div><br>
                            <div style="text-align: center">
                                <button type="submit" class="btn btn-primary" onclick="return confirm('Are you sure ?')" style="border-radius: 10px;"><i class="fa fa-save"></i> Add</button>
                            </div>   
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="box" style="border: 2px solid #3c8dbc">
            <div class="box-body">
                <div class="table-responsive">
                    <table data-page-length='100' class="table table-bordered table-striped getTable">
                        <thead>
                            <tr style="background:#3c8dbc;color:#fff;font-weight:bold;text-transform: uppercase;">
                                <th style="text-align: center">Code</th>
                                <th style="text-align: center">Telephone Allowance</th>
                                <th style="text-align: center">Account No</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="text-align: center">A-122</td>
                                <td style="text-align: center">Welfare Found Loan</td>
                                <td style="text-align: center">5345345</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
        </div>
        <script>
            $(document).ready(function () {
                $("#SettingsPanel").addClass('active');
            });
        </script>
</div>



@endsection