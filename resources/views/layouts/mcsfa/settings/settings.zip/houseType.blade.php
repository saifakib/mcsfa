@extends('layouts.mcsfa.app')

@section('title')
House Type
@endsection

@section('content')

<div id="contentWrapper" style="font-family: Montserrat">
            <!-- Content Header (Page header) -->
        <div class="content-wrapper">
        <section class="content-header">
        <h1>House Type Information</h1>
        <a class="btn btn-primary" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" style="border-radius: 10px;float: right;margin-top:-30px;font-family: Montserrat;color: #fff"><i class="fa fa-plus" aria-hidden="true"></i> Add House</a>
    </section>
    <section class="content animated fadeInRight">
        <div class="box-group" id="accordion">
            <div class="panel" style="border: none">
                <div id="collapseTwo" class="panel-collapse collapse">
                    <div class="box-body" style="border: 2px solid #3c8dbc">
                        <form method="post" action="{{ URL::to('/')}}/saveupdateloan">
                            <input type="hidden" name="_token" value="">
                            <input type="hidden" name="status" value="save">
                            <div class="row">
                                <div class="col-md-6">
                                    <label>House Type <span style="color: red">*</span></label>
                                    <select name="house_type" class="form-control inputnumber" required="">
                                        <option value="" selected="" disabled="">Select Type</option>
                                        <option value="1000000-Assets">Assets-1000000</option>
                                        <option value="2000000-Liabilities">Liabilities-2000000</option>
                                        <option value="3000000-Expenditure">Expenditure-3000000</option>
                                        <option value="4000000-Income">Income-4000000</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label>Max Amount <span style="color: red">*</span></label>
                                    <div class="form-group">
                                        <input type="number" name="max_amount" class="form-control inputnumber" placeholder="Max Amount" required="">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label>Service Charge <span style="color: red">*</span></label>
                                    <div class="form-group">
                                        <input type="text" name="service_charge" class="form-control inputtext" placeholder="Service Charge" required="">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label>Min Amount <span style="color: red">*</span></label>
                                    <div class="form-group">
                                        <input type="number" name="mai_amount" class="form-control inputnumber" placeholder="Mai Amount" required="">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label>House Rent% <span style="color: red">*</span></label>
                                    <div class="form-group">
                                        <input type="text" name="house_rent" class="form-control inputtext" placeholder="House Rent" required="">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label>HR Deduction <span style="color: red">*</span></label>
                                    <div class="form-group">
                                        <input type="text" name="hr_deduction" class="form-control inputnumber" placeholder="HR Deduction" required="">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label class="control-label col-md-3">
                                        Percentage Y/N <span style="color: red">*</span>
                                    </label>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label style="margin-right: 20px">
                                                <input type="radio" name="percentage" value="Y" class="big" required=""><span style="position: relative;left:10px;bottom: 10px">Yes</span>
                                            </label>
                                            <label>
                                                <input type="radio" name="percentage" value="N" class="big" required=""><span style="position: relative;left:10px;bottom: 10px">No</span>
                                            </label>
                                        </div>
                                    </div>
                                
                                </div>
                            </div>
                            <br>
                            <div style="text-align: center">
                                <button type="submit" class="btn btn-primary" onclick="return confirm('Are you sure ?')" style="border-radius: 10px;"><i class="fa fa-save"></i> Add</button>
                            </div>   
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="box" style="border: 2px solid #3c8dbc">
            <div class="box-body">
                <div class="table-responsive">
                    <table data-page-length='100' class="table table-bordered table-striped getTable">
                        <thead>
                            <tr style="background:#3c8dbc;color:#fff;font-weight:bold;text-transform: uppercase;">
                                <th style="text-align: center">Code</th>
                                <th style="text-align: center">Title</th>
                                <th style="text-align: center">Account No</th>
                                <th style="text-align: center">Interest Account</th>
                                <th style="text-align: center">Deduction Account</th>
                                <th style="text-align: center">Deduction Interest Acc</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="text-align: center">1</td>
                                <td style="text-align: center">Welfare Found Loan</td>
                                <td style="text-align: center">45653565</td>
                                <td style="text-align: center">15643665</td>
                                <td style="text-align: center">45653565</td>
                                <td style="text-align: center">15643665</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
        </div>
        <script>
            $(document).ready(function () {
                $("#SettingsPanel").addClass('active');
            });
        </script>
</div>



@endsection